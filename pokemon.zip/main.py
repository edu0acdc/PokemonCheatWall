from data import PokemonData
from memory import MemoryManager
from staticInfo import *
from __init__ import *
from pymem import Pymem

# personality_value = hex(2529813029)  # 4 bytes
# ot_id = hex(1978030688)  # 4 bytes
# decrypt_key = hex(0)  # 4 bytes
# data_str = "5E B9 2F E3 D8 B9 2F E3 45 D9 2F E3 45 A8 2A C2 8B B2 DE CE 45 B8 2F E3 46 BA 2F E5 45 B8 2F E3 45 B8 2F E3 64 B8 02 E3 F8 B8 2F E3 66 90 25 E3"
# data_encrypted = {}  # 48 bytes
# checksum = 65207  # 2 bytes
# runtime_checksum = 0  # 2 bytes
# data = {}  # 48 bytes


def main():

    # pkdata = PokemonData(data_str, personality_value, ot_id, checksum)
    # print(pkdata)

    # pkdata.updateFieldHEX('A', 'Move 1', '0022')
    # pkdata.updateFieldHEX('G', 'Species', '05A')
    # print(pkdata.current_checksum)
    # print(pkdata)

    # print(pkdata.getEncryptedData())

    # pm = Pymem('VisualBoyAdvance.exe')

    # address_val = None
    # for module in pm.list_modules():
    #     if 'VisualBoyAdvance' in module.name:
    #         address_val = pm.read_bytes(
    #             module.lpBaseOfDll + int('0x1D2F0C', 16), 4)

    # address_val = int.from_bytes(
    #     address_val, 'little') + int('0x4360', 16)

    mm = MemoryManager("pokemonAddress.json")
    for pokemon in mm.pokemons:
        print(pokemon.pokemonData)


if __name__ == '__main__':
    main()

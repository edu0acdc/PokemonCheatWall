import json
from data import Pokemon
from pymem import Pymem


class MemoryManager():
    def __init__(self, filePath):
        f = open(filePath)
        self.memoryInfo = json.load(f)
        f.close()
        self.firstPokemonAdress = -1
        self.pokemons = []
        self.pm = Pymem('VisualBoyAdvance.exe')
        self.getFirstPokemonAddress()
        self.createPokemons()

    def getFirstPokemonAddress(self):
        baseAddress = self.pm.read_bytes(
            self.pm.base_address + int(self.memoryInfo['pointer']['baseOffset'], 16), 4)
        self.firstPokemonAdress = int.from_bytes(baseAddress, 'little') + \
            int(self.memoryInfo['pointer']['offset'], 16)

    def createPokemons(self):
        for i in range(6):
            pokemonOffset = i*100
            pokemon_attr = {}
            for attr in self.memoryInfo['attributes']:
                bytes = self.pm.read_bytes(self.firstPokemonAdress +
                                           int(self.memoryInfo['attributes'][attr]['offset']) + pokemonOffset, int(self.memoryInfo['attributes'][attr]['size']))
                # read_mode = 'big' if attr == 'data' else 'little'
                pokemon_attr[attr] = hex(int.from_bytes(bytes, 'little'))
            self.pokemons.append(Pokemon(pokemon_attr))
